package DIP;

public class HTMLMessageWriter {
	public String writeMessage(String msg) {
		System.out.println("HTML"+msg);
		
		return msg;
	}
	
}
