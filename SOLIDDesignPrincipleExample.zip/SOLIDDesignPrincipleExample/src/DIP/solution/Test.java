package DIP.solution;

public class Test {

	public static void main(String[] args) {
		MessageWriter messageWriter=new PDFMessageWriter();
		System.out.println(messageWriter.writeMessage("HTML"));
	}

}
