package DIP.solution;

public interface MessageWriter {
	public String writeMessage(String msg);
}
