package DIP.solution;

public class PDFMessageWriter implements MessageWriter{

	@Override
	public String writeMessage(String msg) {
		// TODO Auto-generated method stub
		return null;
	}

}
