package DIP.solution;

public class HTMLMessageWriter implements MessageWriter {

	@Override
	public String writeMessage(String msg) {
		// TODO Auto-generated method stub
		return null;
	}

}
