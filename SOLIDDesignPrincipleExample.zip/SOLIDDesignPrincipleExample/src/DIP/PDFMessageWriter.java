package DIP;

public class PDFMessageWriter {

	public String writeMessage(String msg) {
		System.out.println("PDF"+msg);
		
		return msg;
	}
}
