package DIP;

public class Test {

	public static void main(String[] args) {
		PDFMessageWriter pdf=new PDFMessageWriter();
		String p=pdf.writeMessage("pdf");
		System.out.println(p);

		HTMLMessageWriter html=new HTMLMessageWriter();
		String h=html.writeMessage("html");
		System.out.println(h);
	}

}
