package LSP;

public class UnionBankService extends BankingService {

	@Override
	public void deposite(Long amount) {
		
	}

	@Override
	public void withdraw(Long amount) {
		
	}

	// not supported
	@Override
	public void HomeLoan() {
		
	}

	@Override
	public void carLoan() {
		
	}

	// not supported
	@Override
	public void personalLoan() {
		
	}

	@Override
	public void goldLoan() {
		
	}

}
