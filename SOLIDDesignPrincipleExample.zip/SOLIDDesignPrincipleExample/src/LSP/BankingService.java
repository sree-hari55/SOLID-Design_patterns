package LSP;

public abstract class BankingService {

	public abstract void deposite(Long amount);
	public abstract void withdraw(Long amount);
	public abstract void HomeLoan();
	public  abstract void carLoan();
	public abstract void personalLoan();
	public abstract void goldLoan();
	
}
