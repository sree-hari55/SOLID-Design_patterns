package LSP.solution;

public interface LoanService {

	public abstract void HomeLoan();
	public  abstract void carLoan();
	public abstract void personalLoan();
	public abstract void goldLoan();
}
