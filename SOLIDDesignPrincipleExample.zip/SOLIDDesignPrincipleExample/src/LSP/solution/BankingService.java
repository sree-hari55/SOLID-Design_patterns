package LSP.solution;

public interface BankingService {
	public abstract void deposite(Long amount);
	public abstract void withdraw(Long amount);
}
