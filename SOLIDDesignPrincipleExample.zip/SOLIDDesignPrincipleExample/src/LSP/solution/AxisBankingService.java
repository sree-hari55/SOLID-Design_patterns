package LSP.solution;

public class AxisBankingService implements BankingService{

	@Override
	public void deposite(Long amount) {
		
	}

	@Override
	public void withdraw(Long amount) {
		
	}

}
