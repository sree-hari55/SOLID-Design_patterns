package LSP;

public class SBIBAnkingService extends BankingService{

	@Override
	public void deposite(Long amount) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void withdraw(Long amount) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void HomeLoan() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void carLoan() {
		// TODO Auto-generated method stub
		
	}

	// not supported
	@Override
	public void personalLoan() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void goldLoan() {
		// TODO Auto-generated method stub
		
	}

}
