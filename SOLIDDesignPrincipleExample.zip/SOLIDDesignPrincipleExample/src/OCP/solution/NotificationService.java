package OCP.solution;

public interface NotificationService {

	public void send(String medium);
}
