package OCP.solution;

public class MailNotifictionService implements NotificationService {

	@Override
	public void send(String medium) {
	}

}
