package OCP.solution;

public class SMSNotificationService implements NotificationService{

	@Override
	public void send(String medium) {
	
	}

}
