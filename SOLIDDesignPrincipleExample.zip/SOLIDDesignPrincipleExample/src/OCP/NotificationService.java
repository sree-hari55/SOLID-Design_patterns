package OCP;

public class NotificationService {

	// If we add any other medium like whatsapp then we need to change this class so it is voilating OCP  
	public void send(String medium) {
		if(medium.equals("mail")) {
            // sending message to mail
		}else if(medium.equals("sms")) {
			// sending massage to sms
		}
	}
}
