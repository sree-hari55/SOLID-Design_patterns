package ISP.solution;

public interface NotificationService {
	public abstract void sendNotifiction(String medium);
}
