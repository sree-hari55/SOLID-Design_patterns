package SRP.solution;

public class ZomatoService {

	public void createOrder(String orderInfo) {
		System.out.println("order created successfully");
	}
		
	public String getOrder(String orderId) {
		return "order"+orderId;
	}
	
	public void updateOrder(String orderInfo) {
		System.out.println("order has updated");
	}
}
