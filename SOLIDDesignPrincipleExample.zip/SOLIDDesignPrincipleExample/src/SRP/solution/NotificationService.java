package SRP.solution;

public class NotificationService {

	public void sendNotification(String orderInfo,String medium) {
		System.out.println();
	}
}
