package SRP;


public class ZomatoService  {
	
	public void createOrder(String orderInfo) {
		System.out.println("order created successfully");
	}
	
	// here notification service is not related to ZomatoService so it is voilating srp 
	public void sendNotification(String orderInfo,String medium) {
		System.out.println();
	}
	
	public String getOrder(String orderId) {
		return "order"+orderId;
	}
	
	public void updateOrder(String orderInfo) {
		System.out.println("order has updated");
	}

}
